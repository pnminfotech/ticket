<?php

defined( 'BASEPATH' ) OR exit( 'No direct script access allowed' );

// From CodeIgniter Core:
$lang['pagination_first_link'] = '&lsaquo; First';
$lang['pagination_next_link']  = '&gt;';
$lang['pagination_prev_link']  = '&lt;';
$lang['pagination_last_link']  = 'Last &rsaquo;';
